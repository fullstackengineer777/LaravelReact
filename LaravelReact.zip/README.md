# LaravelReact
This is the web application that uses Laravel as backend and React as frontend.<br/>
This project is very good if you want to combind Laravel and React.<br/>
I suffered a lot for errors but eventually succeeded on this project. :) <br/>
# How to use

In my experience, this help doesn't work with this above command. It is only right in theory. <br/>
But this project works well, so I suggest to downland and run on your local computer this project. <br/>
An error can occour if you follow the instructions for the confliction of Laravel version and React version. <br/>

# How to combine Laravel and React.
