import 'bootstrap/dist/css/bootstrap.min.css';

require('./components/RootApp');
